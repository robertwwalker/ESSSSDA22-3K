library(lmtest)
library(dlnm)
library(foreign)
library(orcutt)

#load data and create lag structure
bush<-read.dta("BUSHJOB.DTA")

t.s11<-ts(bush$s11)
t.iraq<-ts(bush$iraq)
t.approve<-ts(bush$approve)
lag.approve<-lag(t.approve,-1)

bush.2<-ts.union(t.s11,t.iraq,t.approve,lag.approve)

#run OLS models with and without a lagged DV (static and Koyck)
mod.no.lag<-lm(approve~s11+iraq,data=bush); summary(mod.no.lag)
mod.lag<-lm(t.approve~lag.approve+t.s11+t.iraq,data=bush.2); summary(mod.lag)

#run Durbin-Watson and Breusch-Godfried tests
dwtest(mod.no.lag)
bgtest(mod.no.lag)
bgtest(mod.lag)

#run Cochrane-Orcutt
mod.fgls <- cochrane.orcutt(mod.no.lag); summary(mod.fgls)

#The results differ. In this case, I'd say that pulse inputs probably require an LDV for the full effect to enter the model.

####DYNAMICS####
#Unrestricted distributed lag model
lag.x<-lag(t.s11,-1)
lag2.x<-lag(t.s11,-2)
lag3.x<-lag(t.s11,-3)
lag4.x<-lag(t.s11,-4)
lag5.x<-lag(t.s11,-5)
bush.3<-ts.union(t.s11,t.iraq,t.approve,lag.approve,lag.x,lag2.x,lag3.x,lag4.x,lag5.x)

mod.unrestricted <-lm(t.approve~t.s11+lag.x+lag2.x+lag3.x+lag4.x+lag5.x,data=bush.3); summary(mod.unrestricted)
mod.koyck<-lm(t.approve~lag.approve+t.s11,data=bush.2); summary(mod.koyck)

#Comparing coefficients
unrestricted<-mod.unrestricted$coef[-1]
koyck<-c(24.0644,24.0644*.9296,24.0644*.9296^2,24.0644*.9296^3,24.0644*.9296^4,24.0644*.9296^5)

plot(y=unrestricted,x=c(0:5),ylim=c(0,28),type='h',col='blue',main="Comparing Effects:Unrestricted in Blue")
par(new=T)
plot(y=koyck,x=c(0:5+.1),ylim=c(0,28),xlim=c(0,5),xlab="",ylab="",axes=F,type='h')
abline(h=0, col='gray60')

#Estimate an Almon Model
basis.s11<-crossbasis(bush$s11, vartype="poly", vardegree=2)
basis.t<-crossbasis(bush$t, vartype="poly", vardegree=2)
mod.almon<-lm(approve~basis.s11+iraq,data=bush); summary(mod.almon)
mod.almon.2<-lm(approve~basis.t+s11+iraq,data=bush); summary(mod.almon.2)
