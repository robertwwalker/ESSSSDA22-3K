#Patrick Brandt's documentation for MSBVAR on CRAN.###
library(MSBVAR)

#load data
data(IsraelPalestineConflict)

#create a vector of variable names
varnames <- colnames(IsraelPalestineConflict)

#specify Bayesian Vector Autoregression Model
fit.BVAR <- szbvar(IsraelPalestineConflict, p=6, z=NULL,
                   lambda0=0.6, lambda1=0.1,
                   lambda3=2, lambda4=0.25, lambda5=0, mu5=0,
                   mu6=0, nu=3, qm=4,
                   prior=0, posterior.fit=FALSE)

# Draw from the posterior pdf of the impulse responses.
posterior.impulses <- mc.irf(fit.BVAR, nsteps=10, draws=5000)

# Plot the responses
plot(posterior.impulses, method=c("Sims-Zha2"), component=1,
     probs=c(0.16,0.84), varnames=varnames) 
