library(vars)

#load data on the Canadian economy: productivity, employment, unemployment, real wage
data(Canada)

#run a VAR model
var.model <-VAR(Canada, p=2, type="const") #type could also be "none", "trend", or "both"

#allow the BIC to choose the best lag length
var.model.2 <-VAR(Canada, p=2, lag.max=10, ic="AIC", type="const")

#Assess the model
plot(var.model)

#test for serial correlation
serial.test(var.model, lags.pt = 16, type = "PT.adjusted")

#Does employment have a Granger causal effect?
causality(var.model, cause="e")

#What's the impulse response if we perturb employment?
var.model.irf <- irf(var.model, impulse = "e", response = c("prod", "rw", "U"), boot =
                       FALSE)

#Impulse response analysis
plot(var.model.irf)

#the following is necessary if you do not want to use the whole data set in your VAR model:
Canada.2<-as.data.frame(Canada)
e<-ts(Canada.2$e)
rw<-ts(Canada.2$rw)
U<-ts(Canada.2$U)
prod<-ts(Canada.2$prod)
Canada.3<-ts.union(e,rw,U,dframe=TRUE)

#run a VAR model where productivity is exogenous
var.with.exogenous <-VAR(Canada.3, p=2, type="const", exogen=prod)
