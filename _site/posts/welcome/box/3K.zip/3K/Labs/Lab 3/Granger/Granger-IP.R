data<-read.csv('IPak.csv')

y<-as.ts(data$India)
x<-as.ts(data$Pakistan)
l.y<-lag(data$India,-1)
l2.y<-lag(data$India,-2)
l3.y<-lag(data$India,-3)
l4.y<-lag(data$India,-4)
l.x<-lag(data$Pakistan,-1)
l2.x<-lag(data$Pakistan,-2)
l3.x<-lag(data$Pakistan,-3)
l4.x<-lag(data$Pakistan,-4)
data.2<-ts.union(y,x,l.y,l2.y,l3.y,l4.y,l.x,l2.x,l3.x,l4.x,dframe=TRUE)
#I'm going with 4 lags here, but it's up to you!

# Do Pakistan's expenditures cause India's.
# Start with linear models of y.
y.with.x<-lm(y~l.y+l2.y+l3.y+l4.y+l.x+l2.x+l3.x+l4.x,data=data.2)
y.without.x<-lm(y~l.y+l2.y+l3.y+l4.y,data=data.2)

#Block F-test that Pakistan informs our conditional expectation of India:
anova(y.with.x, y.without.x)
#It's not significant.

#Does India's expenditures cause Pakistan's?
x.with.y<-lm(x~l.x+l2.x+l3.x+l4.x+l.y+l2.y+l3.y+l4.y,data=data.2)
x.without.y<-lm(x~l.x+l2.x+l3.x+l4.x,data=data.2)

#Block F-test that India informs our conditional expectation of Pakistan:
anova(x.with.y, x.without.y)
#It's significant, which suggests India's expenditures are exogenous to Pakistan's (consistent with Freeman 1983).

#QUICK ROBUSTNESS CHECK: TWO LAGS
#Does Pakistan influence India?
y.with.x<-lm(y~l.y+l2.y+l.x+l2.x,data=data.2)
y.without.x<-lm(y~l.y+l2.y,data=data.2)
anova(y.with.x, y.without.x)

#Does India Influence Pakistan?
x.with.y<-lm(x~l.x+l2.x+l.y+l2.y,data=data.2)
x.without.y<-lm(x~l.x+l2.x,data=data.2)
anova(x.with.y, x.without.y)
#Same findings.