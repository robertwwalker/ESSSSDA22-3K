library(plm)
data(EmplUK)
# To make it match the Stata data.
EmplUK$n <- log(EmplUK$emp)
EmplUK$w <- log(EmplUK$wage)
EmplUK$k <- log(EmplUK$capital)
EmplUK$ys <- log(EmplUK$output)
# Can just use log syntax to solve it.
# Arellano and Bond (1991), table 4(a1) 
Table4.a1 <- pgmm(log(emp) ~ lag(log(emp), 1:2) + lag(log(wage), 0:1) + lag(log(capital), 0:2) + lag(log(output), 0:2) | lag(log(emp), 2:99), data = EmplUK, effect = "twoways", model = "onestep")
summary(Table4.a1)
## Arellano and Bond (1991), table 4b 
Table4.b <- pgmm(log(emp) ~ lag(log(emp), 1:2) + lag(log(wage), 0:1)
                 + log(capital) + lag(log(output), 0:1) | lag(log(emp), 2:99),
                 data = EmplUK, effect = "twoways", model = "twosteps")
# To make it match Stata
summary(Table4.b, robust=FALSE)
# Or with Robust [Notice it is default]
summary(Table4.b)
## Blundell and Bond (1998) table 4
Table4.BB <- pgmm(log(emp) ~ lag(log(emp), 1)+ lag(log(wage), 0:1) +
                    lag(log(capital), 0:1) | lag(log(emp), 2:99) +
                    lag(log(wage), 2:99) + lag(log(capital), 2:99),        
                  data = EmplUK, effect = "twoways", model = "onestep", 
                  transformation = "ld")
summary(Table4.BB, robust = TRUE)
