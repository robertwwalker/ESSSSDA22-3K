# R Solution to Lab 2
library(foreign) # The R Package for importing data formats.
library(plm)
agl.data <- read.dta("agl.dta") # Import stata data
# Question 1: ANCOVA
# Estimate the model with pooled slopes and intercepts.
agl.pool.lm <- lm(growth~lagg1+opengdp+openex+openimp+leftc+central+inter, data=agl.data)
agl.pool <- plm(growth~lagg1+opengdp+openex+openimp+leftc+central+inter, data=agl.data, index=c("country","year"))
# Estimate unit intercepts and pooled slopes
agl.dv <- lm(growth~lagg1+opengdp+openex+openimp+leftc+central+inter+as.factor(country), data=agl.data)
# Estimate unit intercepts and unit slopes
agl.big <- lm(growth~lagg1+opengdp+openex+openimp+leftc+central+inter+as.factor(country)*lagg1, data=agl.data)
# Estimate pooled intercept and unit slopes
agl.pooled.intercept <- lm(growth~lagg1+opengdp+openex+openimp+leftc+central+inter+as.factor(country):lagg1, data=agl.data)
# Compare them using the ANOVA command for model comparison.
anova(agl.pool.lm,agl.dv)
anova(agl.pool.lm,agl.big)
anova(agl.pool.lm,agl.pooled.intercept)

# Question 2: Between Estimator
library(plm)
agl.btw <- plm(growth~lagg1+opengdp+openex+openimp+leftc+central+inter, data=agl.data, model="between", index=c("country","year"))
summary(agl.btw)

# Question 3: Within Estimator
agl.with <- plm(growth~lagg1+opengdp+openex+openimp+leftc+central+inter, data=agl.data, model="within", index=c("country","year"))
summary(agl.with)
# Cross-Sectional Dependence?
pcdtest(growth~lagg1+opengdp+openex+openimp+leftc+central+inter, data=agl.data, model="within", index=c("country","year"))

# Question 3: RE Estimator
agl.re1 <- plm(growth~lagg1+opengdp+openex+openimp+leftc+central+inter, data=agl.data, model="random", index=c("country","year"))
agl.re2 <- plm(growth~lagg1+opengdp+openex+openimp+leftc+central+inter, data=agl.data, model="random", index=c("country","year"), random.method="amemiya")
agl.re3 <- plm(growth~lagg1+opengdp+openex+openimp+leftc+central+inter, data=agl.data, model="random", index=c("country","year"), random.method="walhus")
agl.re4 <- plm(growth~lagg1+opengdp+openex+openimp+leftc+central+inter, data=agl.data, model="random", index=c("country","year"), random.method="nerlove")

# A Hausman comparison
phtest(agl.with,agl.re2)

# xttest0: Breusch and Pagan's LM test of random effects
plmtest(agl.pool, effect="individual", type="bp") # Notice there are a few type options here.
# xttest1: Baltagi-Li LM test of random ar/ma1 errors
pbltest(growth~lagg1+opengdp+openex+openimp+leftc+central+inter, data=agl.data, index=c("country","year"))

# First Difference Estimator
agl.fd <- plm(growth~lagg1+opengdp+openex+openimp+leftc+central+inter, data=agl.data, model="fd", index=c("country","year"))
