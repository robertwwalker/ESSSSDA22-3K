library(tidyverse)
# Penn World Tables data on exchange rates
pwt <- foreign::read.dta("pennxrate.dta") %>% data.frame()
pwtg7 <- pwt %>% filter(g7==1)
source(url("https://raw.githubusercontent.com/robertwwalker/DADMStuff/master/xtsum.R"))
xtsum(country~., data=pwt)
library(plm) # Need plm to link to the panel unit root tests
pwtpd <- pdata.frame(pwt, index=c("id","year"))
pwtpdg7 <- pdata.frame(pwtg7, index=c("id","year"))
LXR <- pwtpd$lnrxrate
LXRG7 <- pwtpdg7$lnrxrate
purtest(LXRG7)
purtest(LXRG7, exo="intercept")
purtest(LXRG7, exo="trend")
purtest(LXR)
purtest(LXR, exo="intercept")
# IPS
purtest(LXR, exo="intercept", test="ips", lags=4)
# A large N test
purtest(LXR, exo="intercept", test="Pm")
# Null is stationary; note the alternative.  It happens.
purtest(LXR, exo="trend", test="hadri")

