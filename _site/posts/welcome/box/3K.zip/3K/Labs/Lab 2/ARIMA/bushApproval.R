#libraries
library(foreign)
library(TSA)

#load data & view series
bush <- read.dta("BUSHJOB.DTA")
plot(y=bush$approve, x=bush$t, type='l')

#identify arima process
acf(bush$approve,20)
pacf(bush$approve,20)

#unit-root testing
library(urca)
summary(ur.df(bush$approve, type="drift"))
# Fail to reject the unit root null
summary(ur.kpss(bush$approve, type = "mu", use.lag=5))
# fail to reject the null of stationarity at 5 lags with the non-trend version
summary(ur.kpss(bush$approve, type = "mu", lags="short"))
# reject the null of stationarity at 3 lags with the non-trend version
summary(ur.kpss(bush$approve, type = "mu", lags="long"))
# fail to reject the null of stationarity at 10 lags with the non-trend version


#Estimate AR(1) model. Using a bit of theory to justify AR(1).
mod.1 <- arima(bush$approve, order=c(1,0,0))
mod.1

#diagnose arima model
acf(mod.1$residuals,20)
pacf(mod.1$residuals,20)
Box.test(mod.1$residuals,20,"Ljung-Box")

#estimate intervention analysis for september 11 (remember to start with a pulse)
mod.2b <- arimax(bush$approve, order=c(1,0,0), xtransf=bush$s11, transfer=list(c(1,0))) 
mod.2b
#Notes: the parameters are denominator [decay] before numerator term [# of impacts].  This model has one concurrent effect and a decay. 

#Graph the intervention model after predicting it ourselves
y.pred <- 56.0327 + 27.6660*bush$s11 + 27.6660*(0.8984^(bush$t-9))*as.numeric(bush$t>9)
plot(y=bush$approve, x=bush$t, type='l')
lines(y=y.pred, x=bush$t, lty=2)

#We also can combine the AR(1) and intervention features into forecasts. Do this SECOND, though:
full.pred <- bush$approve-mod.2b$residuals
plot(y=bush$approve, x=bush$t)
lines(y=full.pred, x=bush$t)

# Iraq
# movement seems to start one lag out
#simplest specification:
mod.3 <- arimax(bush$approve, order=c(1,0,0), xtransf=cbind(bush$s11,bush$iraq), transfer=list(c(1,0),c(1,0))); mod.3

#Graph the new intervention model
y.pred <- 56.1190+ 26.0329*bush$s11 + 26.0329*(0.9025^(bush$t-9))*as.numeric(bush$t>9) + 3.9335*bush$iraq + 3.9335*(0.7592^(bush$t-27))*as.numeric(bush$t>27)
plot(y=bush$approve, x=bush$t, type='l')
lines(y=y.pred, x=bush$t, lty=2)

# Automagic
plot(y=bush$approve, x=bush$t, type='l')
lines(y=fitted.values(mod.3), x=bush$t, lty=2)